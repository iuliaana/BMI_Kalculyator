﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _33BMIKgribova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();

        }
       

        

        private void button1_Click_1(object sender, EventArgs e)
        {
            float ves = float.Parse(textBox2.Text);
            float rost = float.Parse(textBox1.Text);
            float index = ves / ((rost / 100) * (rost / 100));
            label9.Text = index.ToString();
            trackBar1.Value = Convert.ToInt32(index);

            if (index < 18.5)
            {
                label14.Text = "Недостаточный";
                pictureBox3.Image = Image.FromFile(@"D:\kmpo\repos\33BMIKgribova\33BMIKgribova\images\marathon-skills-2016-bmi-icons\bmi-underweight-icon.png");
            }
            else if (index < 25)
            {
                label14.Text = "Здоровый";
                pictureBox3.Image = Image.FromFile(@"D:\kmpo\repos\33BMIKgribova\33BMIKgribova\images\marathon-skills-2016-bmi-icons\bmi-healthy-icon.png"); 
            }
            else if (index < 30)
            {
                label14.Text = "Избыточный";
                pictureBox3.Image = Image.FromFile(@"D:\kmpo\repos\33BMIKgribova\33BMIKgribova\images\marathon-skills-2016-bmi-icons\bmi-overweight-icon.png");
            }
            else 
            {
                label14.Text = "Ожирение";
                pictureBox3.Image = Image.FromFile(@"D:\kmpo\repos\33BMIKgribova\33BMIKgribova\images\marathon-kills-2016-bmi-icons\bmi-obese-icon.png"); 
            }

        }

        
       

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox1.Image;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox2.Image;
        }

        
    }
}

  


